﻿using GaFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GaFramework_WinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ViewData()
        {
            try
            {
                Grd.DataSource = GaDatabase.Select("SELECT * From Employees").Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message, "View Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Clear();
        }
        private void GetMaxID()
        {
            try
            {
                txtID.Text = GaDatabase.Select("select ISNULL(MAX(id), 0)+1 from Employees").Tables[0].Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error " + ex.Message, "Max ID Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Clear()
        {
            ViewData();
            GetMaxID();
            pictureBox1.Image = null;
            txtName.Clear();
            cbSkill.Text = "";
            txtContact.Clear();
            txtName.Focus();
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnSave.Enabled = true;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            //Ask user to select file.
            OpenFileDialog dlg = new OpenFileDialog();
            DialogResult dlgRes = dlg.ShowDialog();
            if (dlgRes != DialogResult.Cancel)
            {
                //Set image in picture box
                pictureBox1.ImageLocation = dlg.FileName;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                /*if (GaWinForms.Validations.TextBoxValidations.On_Save_Check_All_Not_Null(panel1))
                {
                    GaDatabase.Insert("Insert into Employees values (@name,@skill,@contact,@picture)",new string[]{"@name",txtName.Text},new string[]{"@skill", cbSkill.Text},new string[]{"@contact", txtContact.Text}, new object[]{"@picture", GaImage.ImageToByte(pictureBox1.Image)});
                    Clear();
                }*/
                if (GaWinForms.Validations.TextBoxValidations.On_Save_Check_Selected_Not_Null(panel1,txtName) && GaWinForms.Validations.TextBoxValidations.On_Save_Check_MaxLength(this,panel1,txtContact) && GaWinForms.Validations.ComboBoxValidations.On_Save_Check_All_Not_Null(panel1,errorProvider1,"Please Select Some Value"))
                {
                    GaDatabase.Insert("Insert into Employees values (@name,@skill,@contact,@picture)",new string[]{"@name",txtName.Text},new string[]{"@skill", cbSkill.Text},new string[]{"@contact", txtContact.Text}, new object[]{"@picture", GaImage.ImageToByte(pictureBox1.Image)});
                    Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message, "Save Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            GaWinForms.Validations.TextBoxValidations.Is_Letter(txtName, e, errorProvider1, "Please Enter Letters");
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            //GaWinForms.Validations.TextBoxValidations.Is_NotEmpty(txtName, errorProvider1);
            GaWinForms.Validations.TextBoxValidations.On_Leave_Empty(txtName, errorProvider1);
        }

        private void txtContact_Leave(object sender, EventArgs e)
        {
            //GaWinForms.Validations.TextBoxValidations.Is_MaxLength(txtContact, errorProvider1);
            GaWinForms.Validations.TextBoxValidations.Is_MaxLength_NotEmpty(txtContact, errorProvider1);
        }

        private void txtContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            GaWinForms.Validations.TextBoxValidations.Is_Digit(txtContact, e, errorProvider1, "Please Enter Digits");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                GaDatabase.Update("Update Employees set name = @name, skill = @skill, contact = @contact, picture = @picture where id = "+txtID.Text+"", new string[] { "@name", txtName.Text }, new string[] { "@skill", cbSkill.Text }, new string[] { "@contact", txtContact.Text }, new object[] { "@picture", GaImage.ImageToByte(pictureBox1.Image) });
                Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message, "Update Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Grd_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (Grd.RowCount > 0)
                {
                    DataGridViewRow row = this.Grd.Rows[e.RowIndex];
                    txtID.Text = row.Cells["id"].Value.ToString();
                    txtName.Text = row.Cells["name"].Value.ToString();
                    cbSkill.Text = row.Cells["skill"].Value.ToString();
                    txtContact.Text = row.Cells["contact"].Value.ToString();
                    pictureBox1.Image = GaImage.ByteToImage((Byte[])row.Cells["picture"].Value);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                    btnSave.Enabled = false;

                }
            }
            catch
            {

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                GaDatabase.Delete("Delete from Employees where id = " + txtID.Text + "");
                Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message, "Delete Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
    }
}
