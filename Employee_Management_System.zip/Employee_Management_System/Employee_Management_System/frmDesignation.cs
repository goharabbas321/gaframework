﻿using GaFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Employee_Management_System
{
    public partial class frmDesignation : Form
    {
        string eid = "";
        public frmDesignation()
        {
            InitializeComponent();
        }

        private void frmDesignation_Load(object sender, EventArgs e)
        {
            ClearData();
        }
        private void ClearData()
        {
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            ViewData();
            GetMaxID();
            GetEmployee();
            txtDesignation.Text = "";
            txtPay.Text = "";
            txtDesignation.Focus();
            eid = "";
        }
        private void GetEmployee()
        {
            try
            {
                cmbEmployees.DataSource = GaDatabase.Select("select * from Emp_Info").Tables[0];
                cmbEmployees.DisplayMember = "e_name";
                cmbEmployees.ValueMember = "eid";
            }
            catch
            {

            }
        }
        private void GetMaxID()
        {
            try
            {
                txtID.Text = GaDatabase.Select("select ISNULL(MAX(did), 0)+1 from Designation").Tables[0].Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void ViewData()
        {
            try
            {
                dataGridView1.DataSource = GaDatabase.Select("select * from Designation").Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Insert("insert into Designation values(@id,@eid,@name,@des,@pay)", new string[] { "@id", txtID.Text }, new string[] { "@eid", cmbEmployees.SelectedValue.ToString() }, new string[] { "@name", cmbEmployees.Text }, new string[] { "@des", txtDesignation.Text }, new string[] { "@pay", txtPay.Text });
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                    txtID.Text = row.Cells[0].Value.ToString();
                    eid = row.Cells[1].Value.ToString();
                    cmbEmployees.Text = row.Cells[2].Value.ToString();
                    txtDesignation.Text = row.Cells[3].Value.ToString();
                    txtPay.Text = row.Cells[4].Value.ToString();
                    btnDelete.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnSave.Enabled = false;
                }
            }
            catch
            {

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Delete("delete from Designation where did = " + txtID.Text + "");
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Insert("update Designation set eid = @eid, e_name = @name, e_designation = @des, e_pay = @pay where did = @id", new string[] { "@id", txtID.Text }, new string[] { "@eid", cmbEmployees.SelectedValue.ToString() }, new string[] { "@name", cmbEmployees.Text }, new string[] { "@des", txtDesignation.Text }, new string[] { "@pay", txtPay.Text });
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
