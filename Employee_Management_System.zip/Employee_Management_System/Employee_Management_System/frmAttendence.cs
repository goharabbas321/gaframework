﻿using GaFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Employee_Management_System
{
    public partial class frmAttendence : Form
    {
        string eid = "";
        public frmAttendence()
        {
            InitializeComponent();
        }

        private void frmAttendence_Load(object sender, EventArgs e)
        {
            ClearData();
        }
        private void ClearData()
        {
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            ViewData();
            GetMaxID();
            GetEmployee();
            dateAttendence.Text = "";
            cmbStatus.Text = "";
            cmbEmployees.Focus();
            eid = "";
        }
        private void GetEmployee()
        {
            try
            {
                cmbEmployees.DataSource = GaDatabase.Select("select * from Emp_Info").Tables[0];
                cmbEmployees.DisplayMember = "e_name";
                cmbEmployees.ValueMember = "eid";
            }
            catch
            {

            }
        }
        private void GetMaxID()
        {
            try
            {
                txtID.Text = GaDatabase.Select("select ISNULL(MAX(aid), 0)+1 from Attendence").Tables[0].Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void ViewData()
        {
            try
            {
                dataGridView1.DataSource = GaDatabase.Select("select * from Attendence").Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Insert("insert into Attendence values(@id,@eid,@name,@date,@status)", new string[] { "@id", txtID.Text }, new string[] { "@eid", cmbEmployees.SelectedValue.ToString() }, new string[] { "@name", cmbEmployees.Text }, new string[] { "@date", dateAttendence.Text }, new string[] { "@status", cmbStatus.Text });
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                    txtID.Text = row.Cells[0].Value.ToString();
                    eid = row.Cells[1].Value.ToString();
                    cmbEmployees.Text = row.Cells[2].Value.ToString();
                    dateAttendence.Value = (DateTime)row.Cells[3].Value;
                    cmbStatus.Text = row.Cells[4].Value.ToString();
                    btnDelete.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnSave.Enabled = false;
                }
            }
            catch
            {

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Delete("delete from Attendence where aid = " + txtID.Text + "");
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Insert("update Attendence set eid = @eid, e_name = @name, a_date = @date, a_status = @status where aid = @id", new string[] { "@id", txtID.Text }, new string[] { "@eid", cmbEmployees.SelectedValue.ToString() }, new string[] { "@name", cmbEmployees.Text }, new string[] { "@date", dateAttendence.Text }, new string[] { "@status", cmbStatus.Text });
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
