﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GaFramework;

namespace Employee_Management_System.Forms
{
    public partial class frmEmployeeInfromation : Form
    {
        public frmEmployeeInfromation()
        {
            InitializeComponent();
        }
        private void ClearData()
        {
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            ViewData();
            GetMaxID();
            txtName.Text = "";
            txtContact.Text = "";
            pictureBox1.Image = null;
            txtName.Focus();
        }
        private void GetMaxID()
        {
            try
            {
                txtID.Text = GaDatabase.Select("select ISNULL(MAX(eid), 0)+1 from Emp_Info").Tables[0].Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void ViewData()
        {
            try
            {
                dataGridView1.DataSource = GaDatabase.Select("select * from Emp_Info").Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void frmEmployeeInfromation_Load(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog of = new OpenFileDialog();
            //For any other formats
            of.Filter = "Image Files (*.bmp;*.jpg;*.jpeg,*.png)|*.BMP;*.JPG;*.JPEG;*.PNG";
            if (of.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = of.FileName;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Insert("insert into Emp_Info values(@id,@name,@contact,@pic)", new string[] { "@id", txtID.Text }, new string[] { "@name", txtName.Text }, new string[] { "@contact", txtContact.Text }, new object[] { "@pic", GaImage.ImageToByte(pictureBox1.Image) });
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                    txtID.Text = row.Cells[0].Value.ToString();
                    txtName.Text = row.Cells[1].Value.ToString();
                    txtContact.Text = row.Cells[2].Value.ToString();
                    pictureBox1.Image = GaImage.ByteToImage((Byte[])row.Cells[3].Value);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    btnDelete.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnSave.Enabled = false;
                }
            }
            catch
            {

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Delete("delete from Emp_Info where eid = "+ txtID.Text +"");
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                GaDatabase.Insert("update Emp_Info set e_name = @name,e_contact = @contact, pic = @pic where eid = @id", new string[] { "@id", txtID.Text }, new string[] { "@name", txtName.Text }, new string[] { "@contact", txtContact.Text }, new object[] { "@pic", GaImage.ImageToByte(pictureBox1.Image) });
                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
