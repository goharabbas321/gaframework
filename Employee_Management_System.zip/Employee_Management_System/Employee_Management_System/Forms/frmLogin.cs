﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GaFramework;
using Employee_Management_System.Forms;

namespace Employee_Management_System
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds = GaDatabase.Select("select * from Login where username = '"+ txtUsername.Text +"' and password = '"+  txtPassword.Text +"'");
            if (ds.Tables[0].Rows.Count > 0)
            {
                frmMain frm = new frmMain();
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Error");
                ClearData();
            }
        }
        private void ClearData()
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            ClearData();
        }
    }
}
